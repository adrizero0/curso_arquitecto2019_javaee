package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Compra;


@WebServlet("/compras")
public class compras extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String producto=request.getParameter("producto");
		int unidades=Integer.parseInt(request.getParameter("unidades"));
		double precio=Double.parseDouble(request.getParameter("precio"));
		
		Compra c= new Compra(producto, unidades, precio);
		HttpSession sesion=request.getSession();
		sesion.setAttribute("compra", c);
		
		RequestDispatcher rd;
		rd=request.getRequestDispatcher("compra.html");
		rd.forward(request, response);
	}

}
